# Use Case Diagrams – He thong tao sinh de thi
## Danh sach 17 file PUML (chia theo chuc nang)

| # | File | Chuc nang | Actor |
|---|------|-----------|-------|
| 01 | UC01_xac_thuc.puml | Xac thuc & Phan quyen (Dang nhap, Dang xuat, JWT) | Admin, Giao vien, Hoc sinh |
| 02 | UC02_quan_ly_truong.puml | Quan ly thong tin truong hoc | Admin |
| 03 | UC03_khoa_hoc_lop_hoc.puml | Tao khoa hoc, Sinh lop tu dong, Xem lop theo nam hoc | Admin |
| 04 | UC04_quan_ly_thanh_vien.puml | Enroll hoc sinh, Phan cong giao vien, Cap nhat GVCN | Admin |
| 05 | UC05_cau_hinh_danh_muc.puml | Cau hinh mon hoc, chu de, do kho, loai cau hoi, Bloom | Admin |
| 06 | UC06_duyet_cau_hoi.puml | Duyet/tu choi cau hoi trong ngan hang | Admin, Giao vien |
| 07 | UC07_tao_cau_hoi.puml | Tao cau hoi, tag Bloom, upload anh, luu MinIO | Giao vien |
| 08 | UC08_sua_xoa_cau_hoi.puml | Sua / Xoa cau hoi, upload anh cap nhat | Giao vien |
| 09 | UC09_tim_kiem_cau_hoi.puml | Tim kiem & loc cau hoi trong ngan hang | Giao vien |
| 10 | UC10_import_excel.puml | Import hang loat cau hoi tu file Excel, parse, tag Bloom | Giao vien |
| 11 | UC11_tao_mau_de_thi.puml | Tao mau de thi, cau hinh phan thi, ti le do kho, Bloom | Giao vien |
| 12 | UC12_sinh_de_thi.puml | Sinh de tu mau, sinh nhieu ma de, sampling, shuffle | Giao vien |
| 13 | UC13_xuat_de_thi.puml | Preview de thi, xuat PDF, xuat Word, luu MinIO | Giao vien |
| 14 | UC14_giao_de_cho_lop.puml | Giao de thi cho lop hoc cu the | Giao vien |
| 15 | UC15_cham_diem.puml | Cham diem tu dong (MCQ) va thu cong (tu luan) | Giao vien, Hoc sinh |
| 16 | UC16_thong_ke_bao_cao.puml | Thong ke Bloom, bao cao lop, xem ket qua | Giao vien, Hoc sinh |
| 17 | UC17_hoc_sinh_lam_bai.puml | Xem de, lam bai, nop bai, cham tu dong, xem ket qua | Hoc sinh |

## Nguyen tac thiet ke
- Moi file tu dung doc lap, render rieng le khong can include.
- Moi UC bao gom day du include/extend lien quan den chinh no.
- UC dung chung nhieu file (UC_Stats, UC_MinIO, ...) duoc khai bao lai trong tung file.

## Cach render

